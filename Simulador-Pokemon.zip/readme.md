He ido avanzando porque estaba aburrido xdxdxd -Seba

- Struct : ![image](image.png)